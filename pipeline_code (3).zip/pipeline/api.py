#!/usr/bin/env python3
"""
api.py — thin web wrapper around build_pbip.py

This is the "web API" layer: it lets a browser upload the Excel files, runs the
SAME engine (validate + assemble), and streams back the generated .pbip zip.
No Claude API / no AI key is used — v1 is pure deterministic assembly.

Run:
    pip install flask openpyxl
    python api.py
    # then open http://127.0.0.1:5000 in a browser

Endpoints:
    GET  /            -> the simple upload page
    POST /generate    -> multipart file upload; returns the .pbip zip, or
                         JSON {ok:false, problems:[...]} if validation fails
"""
import io, tempfile, shutil
from pathlib import Path
from flask import Flask, request, send_file, jsonify, Response

import build_pbip as engine   # reuse validate() / assemble() / zip_dir()

app = Flask(__name__)

PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><title>Payroll & CC — Report Builder</title>
<style>
 body{font-family:Segoe UI,system-ui,sans-serif;max-width:640px;margin:40px auto;padding:0 16px;color:#1C2833}
 h1{font-size:20px} .card{border:1px solid #D5D8DC;border-radius:8px;padding:20px;background:#EBF5FB}
 input[type=file]{margin:12px 0} button{background:#1A3352;color:#fff;border:0;border-radius:6px;padding:10px 18px;font-size:14px;cursor:pointer}
 button:disabled{opacity:.5;cursor:default} .msg{margin-top:16px;white-space:pre-wrap;font-size:14px}
 .err{color:#CB4335} .ok{color:#1E8449} ul{font-size:13px;color:#717D7E}
</style></head><body>
<h1>Payroll &amp; CC Dashboard — Report Builder</h1>
<div class="card">
 <p>Select the source Excel files, then Generate. You'll get a <b>.pbip</b> to open in Power BI Desktop.</p>
 <input id="files" type="file" multiple accept=".xlsx"><br>
 <button id="go" onclick="go()">Generate report</button>
 <div id="msg" class="msg"></div>
 <ul>
  <li>Expected: Payroll Raw Data, AWS Raw Data, Agent Data, AWS_Mapping_File,
      Payroll_Mapping_File, Awaiting Acceptance tickets, Ready State (.xlsx)</li>
 </ul>
</div>
<script>
async function go(){
 const b=document.getElementById('go'), m=document.getElementById('msg');
 const files=document.getElementById('files').files;
 if(!files.length){m.className='msg err';m.textContent='Pick the .xlsx files first.';return;}
 const fd=new FormData(); for(const f of files) fd.append('files',f,f.name);
 b.disabled=true; m.className='msg'; m.textContent='Validating and building…';
 try{
  const r=await fetch('/generate',{method:'POST',body:fd});
  if(!r.ok){ const j=await r.json(); m.className='msg err';
    m.textContent='Validation failed:\\n- '+j.problems.join('\\n- '); b.disabled=false; return; }
  const blob=await r.blob(); const url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download='Payroll_CC_report.zip'; a.click();
  m.className='msg ok'; m.textContent='Done — download started. Unzip, open the .pbip, set DataFolder, Refresh.';
 }catch(e){ m.className='msg err'; m.textContent='Error: '+e; }
 b.disabled=false;
}
</script></body></html>"""


@app.get("/")
def index():
    return Response(PAGE, mimetype="text/html")


@app.post("/generate")
def generate():
    work = Path(tempfile.mkdtemp())
    data_dir = work / "data"
    data_dir.mkdir()
    try:
        # 1) save uploads
        for f in request.files.getlist("files"):
            (data_dir / Path(f.filename).name).write_bytes(f.read())
        # 2) validate (same engine as CLI)
        problems, _ = engine.validate(data_dir)
        if problems:
            return jsonify(ok=False, problems=problems), 400
        # 3) assemble + zip, then read into memory so we can clean up now
        root = engine.assemble(data_dir, work / "build")
        out_zip = work / "Payroll_CC_report.zip"
        engine.zip_dir(root, out_zip)
        data = out_zip.read_bytes()
        return send_file(io.BytesIO(data), as_attachment=True,
                         download_name="Payroll_CC_report.zip",
                         mimetype="application/zip")
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
